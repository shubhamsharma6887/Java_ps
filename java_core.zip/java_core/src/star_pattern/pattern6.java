package star_pattern;

public class pattern6 {
    public static void main(String[] args) {
        int a = 5;
        for (int i=0;i<5;i++){
            for (int j=70+i-a;j>=65;j--){
                System.out.print((char) j+" ");
            }
            System.out.println();
        }
    }
}
