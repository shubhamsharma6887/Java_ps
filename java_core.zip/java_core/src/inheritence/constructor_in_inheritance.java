package inheritence;

class MyBase{
    int x;
    public MyBase(){
        System.out.println("i am a constructor");
    }
    public MyBase(int a){
        System.out.println("i am a overload constructor with value of a as: "+a);
    }
    public int getX(){
        return x;
    }
    public void setX(int x){
        this.x=x;
    }
}
class MyDerived extends MyBase{
    int y;
    public MyDerived(){
        System.out.println("i am MyDerived class constructor");
    }
    public MyDerived(int a, int b){
        super(a);
        System.out.println("i am a overload constructor of derived with value of b as: "+b);
    }
    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}
class ChildOfDerived extends MyDerived{
    public ChildOfDerived(){
        System.out.println("i am child of derived constructor");
    }
    public ChildOfDerived(int a, int b, int c){
        super(a,b);
        System.out.println("i am a overload constructor of ChildOfDerived with value of c as: "+c);
    }
}
public class constructor_in_inheritance {
    public static void main(String[] args) {
        //MyBase b = new MyBase(1);
        //MyDerived d = new MyDerived(4,9);
        ChildOfDerived cd = new ChildOfDerived(12,15,18);
    }
}
