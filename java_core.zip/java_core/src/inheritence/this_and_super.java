package inheritence;

class Random_class{
    int a;
    Random_class(int a){
        this.a=a;
    }
    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int retrunone(){
        return 1;
    }
}
class DoClass extends Random_class{
    public DoClass(int c){
        super(c);
        System.out.println("i am an constructor");
    }
}
public class this_and_super {
    public static void main(String[] args) {
        Random_class r = new Random_class(5);
        DoClass d = new DoClass(4);
        System.out.println(r.getA());


    }
}
