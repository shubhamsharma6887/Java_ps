package tushar_questions;

import java.util.LinkedList;

public class first_and_last_occrance {
    public static void main(String[] args) {
        String s = "hello world";
        s=s.toLowerCase();
        LinkedList<Integer> index = new LinkedList<>();
        for (int i=0;i<s.length();i++){
            if (s.charAt(i)=='o'){
                index.add(i);
            }
        }
        System.out.println(index.getFirst());
        System.out.println(index.getLast());
    }
}
