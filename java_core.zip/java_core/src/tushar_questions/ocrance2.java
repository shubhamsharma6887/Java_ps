package tushar_questions;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class ocrance2 {
    public static void main(String[] args) {
        String s = "qwetdsbjdsdssdkhsjfdsjkjjjfhkskjznxcm";
        LinkedHashMap<Character,Integer> count = new LinkedHashMap<>();
        for (int i=0;i<s.length();i++){
            if (count.containsKey(s.charAt(i))){
                count.put(s.charAt(i),count.get(s.charAt(i))+1);
            } else {
                count.put(s.charAt(i),1);
            }
        }
        System.out.println(count);
        int max = Collections.max(count.values());
        char maxChar = ' ';

        for (Map.Entry<Character, Integer> entry : count.entrySet()) {
            if (entry.getValue() == max) {
                if (maxChar == ' ' || entry.getKey() < maxChar) {
                    maxChar = entry.getKey();
                }
            }
        }

        System.out.println(maxChar);
    }
}