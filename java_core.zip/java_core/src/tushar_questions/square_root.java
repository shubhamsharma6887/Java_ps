package tushar_questions;

public class square_root {
    public static void main(String[] args) {
        int[] arr = {33,25,4,144,88};
        int num1=0;

        for (int i=0;i<arr.length;i++){
            double num = Math.sqrt(arr[i]);
            num1=(int) num;
            if (num==num1)
            {
                System.out.println("square root of "+arr[i]+" = "+num1);
            }
        }
    }
}
