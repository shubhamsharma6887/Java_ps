package tushar_questions;

public class prime_number_in_given_range {
    public static void main(String[] args) {
        int start = 1;
        int end = 100;

        for (int i = start; i <= end; i++) {
            if (i <= 1) {
                continue;
            }
            boolean flag = true;
            for (int j = 2; j <= Math.sqrt(i); j++) {
                if (i % j == 0) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                System.out.println(i);
            }
        }
    }
}