package tushar_questions;

public class sum_of_all_digits {
    public static void main(String[] args) {
        int num=2354637, sum=0,result=0;
        while (num>0){
            sum=num%10;
            if (sum%2!=0){
                result+=sum;
            }
            num/=10;
        }
        System.out.println(result);
    }
}
