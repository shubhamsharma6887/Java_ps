package tushar_questions;

import java.util.ArrayList;
import java.util.List;

public class lcm {
    public static void main(String[] args) {
       String s="this is an amazing program ";
       String add="";
       ArrayList<String> arr = new ArrayList<>();
       for (int i=0;i<s.length();i++){
           if (s.charAt(i)==' '){
               arr.add(add);
               add="";
           } else {
               add+=s.charAt(i);
           }

       }
       for (int i=arr.size()-1;i>=0;i--){
           System.out.print(arr.get(i)+" ");
       }

    }

}
