package tushar_questions;

import java.util.ArrayList;
import java.util.List;

public class longest_palindrome {
    public static boolean isPalindrome(String s){
        String rev ="";
        for(int i = s.length()-1;i>=0;i--){
            rev+=s.charAt(i);
        }
        if(rev.equals(s)){
            return  true;
        }
        return false;
    }
    public static void main(String[] args) {
        String s = "ababccbaba";
        List<String>palindromes = new ArrayList<>();
        for(int i =0;i<s.length();i++){
            int index = s.indexOf(s.charAt(i),i+1);
            if(index<0){
                continue;
            }
            String substring = s.substring(i,index+1);
            if(isPalindrome(substring)){
                palindromes.add(substring);

            }
        }
        int maxLength = 0;
        String ans= "";
        for(int i =0;i<palindromes.size();i++){
            if(maxLength<palindromes.get(i).length()){
                maxLength=palindromes.get(i).length();
                ans= palindromes.get(i);
            }
        }
        System.out.println(ans+" "+maxLength);
        System.out.println(palindromes);
    }
}
