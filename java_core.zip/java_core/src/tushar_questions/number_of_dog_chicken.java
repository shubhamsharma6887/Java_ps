package tushar_questions;

import java.util.Scanner;

public class number_of_dog_chicken {
    public static void main(String[] args) {
        int chik=0, dog=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of head");
        int head = sc.nextInt();
        System.out.println("enter the number of legs");
        int legs = sc.nextInt();
        if ((double)legs/4==(double) head){
            System.out.println("There are "+head+" dogs");
        }
        if ((double)(legs-legs%4)/4==(double) head-1){
            head= head - 1 ;
            chik+= 1;
            System.out.println("There are "+head+" dogs and "+chik+" chicken");
        }
        if ((double)legs/2==(double) head){
            System.out.println("There are "+head+" chicken");
        }
        if ((double)((legs)/2)-2==(double) head-1){
            head=head-1;
            dog+=1;
            System.out.println("There are "+head+" chicken and "+dog+" dog");
        }
        System.out.println(legs%4);
    }
}
