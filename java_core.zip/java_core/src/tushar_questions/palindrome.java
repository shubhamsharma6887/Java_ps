package tushar_questions;

public class palindrome {
    public static void main(String[] args) {
        String s = "abca";
        String ok = "";
        for (int i=0;i<s.length();i++){
            for (int j=0;j<s.length();j++){
                if (i==j){
                    continue;
                } else {
                    ok+=s.charAt(i);
                }
                System.out.println(ok);
            }
        }
    }
}
