package tushar_questions;

import java.util.*;
public class matrix_tushar {
    public static void makeZero(int ans [] [],int i , int j){
        for(int k=0;k<3;k++){
            ans[k][j]=0;
            ans[i][k]=0;
        }
    }
    public static void main(String[] args) {
        int arr[] []= {{1,2,3},{4,5,0},{6,7,8}};
        int ans [] [] = {{1,2,3},{4,5,0},{6,7,8}};
        for(int i =0;i<3;i++){
            for(int j=0;j<3;j++){
                if(arr[i][j]==0){
                    makeZero(ans,i,j);

                }


            }
        }

        for(int i =0;i<3;i++){
            for(int j =0;j<3;j++){
                System.out.print(ans[i][j]+" ");
            }
            System.out.println();

        }

    }
}