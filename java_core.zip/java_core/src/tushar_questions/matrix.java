package tushar_questions;

public class matrix {
    public static void main(String[] args) {
        int[][] matrix = {{1, 2, 3}, {4, 0, 6}, {7, 8, 9}};
        for (int i =0;i<matrix.length;i++){
            for (int j=0;j<matrix[i].length;j++){
                if (matrix[i][j]==0){
                    matrix[0][1] = 0;
                }
            }
        }

    }
}
