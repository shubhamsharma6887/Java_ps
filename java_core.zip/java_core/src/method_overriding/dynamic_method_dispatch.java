package method_overriding;

class Phone {
    public void name(){
        System.out.println("my name is java 1");
    }
    public void greet(){
        System.out.println("good morning");
    }
}
class SmartPhone extends Phone {
    public void name(){
        System.out.println("my name is java 2");
    }
    public void swagat(){
        System.out.println("apka swagat hai");
    }
}
public class dynamic_method_dispatch {
    public static void main(String[] args) {
        Phone obj1 = new Phone();
        obj1.name();
        //SmartPhone smobj = new SmartPhone();
        //smobj.swagat();
        Phone obj = new SmartPhone();
        obj.greet();
        obj.name();
       // obj.swagat();  // not allowed

    }
}
