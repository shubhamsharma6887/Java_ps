package string_problems;

//How do you count a number of vowels and consonants in a given string?
import java.util.LinkedHashMap;
import java.util.Map;

public class number_of_vowel_in_String {
    public static void main(String[] args) {
        String s ="Java is a high-level, general-purpose, object-oriented, and secure programming language developed by James Gosling";
        s=s.toLowerCase();
        int vowel=0, consonant=0;
        LinkedHashMap<Character,Integer> count = new LinkedHashMap<>();
        for (int i=0;i<s.length();i++){

            if (Character.isLetter(s.charAt(i))){
                if(count.containsKey(s.charAt(i))){
                    count.put(s.charAt(i),count.get(s.charAt(i))+1);
                } else {
                    count.put(s.charAt(i),1);
                }
            }
        }

        for (Map.Entry<Character,Integer> ok:count.entrySet()) {
            if (ok.getKey()=='a'){
                vowel+=ok.getValue();
            }
            else if (ok.getKey()=='e'){
                vowel+=ok.getValue();
            }
            else if (ok.getKey()=='i'){
                vowel+=ok.getValue();
            }
            else if (ok.getKey()=='o'){
                vowel+=ok.getValue();
            }
            else if (ok.getKey()=='u'){
                vowel+=ok.getValue();
            } else {
                consonant+=ok.getValue();
            }
        }
        System.out.println("vowel = "+vowel+" consonant = "+consonant);
    }
}
