package string_problems;

public class problam9 {
    public static void main(String[] args) {
        String s = "ab_bcd!ef";
        int pos1=0;
        int pos2=0;
        char symbol1='0';
        char symbol2='0';
        String rev="";
        for (int i=s.length()-1;i>=0;i--){
            if (Character.isLetter(s.charAt(i))){
                rev+=s.charAt(i);
            }
            else if(pos1==0){
                pos1=i;
                symbol1=s.charAt(i);
            }
            else {
                pos2=i;
                symbol2=s.charAt(i);
            }
        }
        for (int j = 0;j<rev.length();j++){
            if (pos1==j){
                System.out.print(symbol1);
            } else if (pos2==j) {
                System.out.print(symbol2);
            }
            System.out.print(rev.charAt(j));
        }
    }
}
