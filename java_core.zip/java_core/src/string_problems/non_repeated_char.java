package string_problems;

//How do you print the first non-repeated character from a string?
import java.util.LinkedHashMap;
import java.util.Map;

public class non_repeated_char {
    public static void main(String[] args) {
        String s = "shubham sharma";
        LinkedHashMap<Character,Integer> count = new LinkedHashMap<>();
        for (int i=0;i<s.length();i++){
            if (count.containsKey(s.charAt(i))){
                count.put(s.charAt(i),count.get(s.charAt(i))+1);
            } else {
                count.put(s.charAt(i),1);
            }
        }
        for (Map.Entry<Character,Integer> ok:count.entrySet()){
            if (ok.getValue()==1){
                System.out.println(ok.getKey());
                break;
            }

        }
    }
}
