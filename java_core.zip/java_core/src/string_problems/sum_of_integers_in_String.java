package string_problems;

public class sum_of_integers_in_String {
    public static void main(String[] args) {
        String s = "Shub2ham S4har8ma";
        int sum=0;
        for (int i=0;i<s.length();i++){
            if ((int)(s.charAt(i))>=48 && (int)(s.charAt(i))<=57){
                sum+=(int)(s.charAt(i)-48);
            }
        }
        System.out.println(sum);
    }
}
