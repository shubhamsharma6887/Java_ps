package string_problems;

import java.util.*;

public class problam10 {
    public static void main(String[] args) {
        String[] arr = {"shubham","works","harder"};
        HashMap<Character,Integer> count = new HashMap<>();
        for (int i = 0;i<arr.length;i++){
            for (int j = 0;j<arr[i].length();j++){
                if (count.containsKey(arr[i].charAt(j))){
                    count.put(arr[i].charAt(j),count.get(arr[i].charAt(j))+1);
                } else {
                    count.put(arr[i].charAt(j),1);
                }
            }
        }
        List<Map.Entry<Character, Integer>> entryList = new ArrayList<>(count.entrySet());
        // Sort the entryList based on values using a custom Comparator
        Collections.sort(entryList, new Comparator<Map.Entry<Character, Integer>>() {
            @Override
            public int compare(Map.Entry<Character, Integer> e1, Map.Entry<Character, Integer> e2) {
                return e1.getValue().compareTo(e2.getValue()); // Sort in descending order of values
            }
        });
        for (Map.Entry<Character, Integer> entry : entryList) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}

