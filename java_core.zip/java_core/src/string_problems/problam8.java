package string_problems;

import java.util.HashMap;

public class problam8 {
    public static void main(String[] args) {
        String[] arr = {"shubham","works","harder"};
        HashMap<Character,Integer> count = new HashMap<>();
        for (int i = 0;i<arr.length;i++){
            for (int j = 0;j<arr[i].length();j++){
                if (count.containsKey(arr[i].charAt(j))){
                    count.put(arr[i].charAt(j),count.get(arr[i].charAt(j))+1);
                } else {
                    count.put(arr[i].charAt(j),1);
                }
            }
        }
        System.out.println(count.toString());

    }
}
