package string_problems;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class peak_element_greater_then_neighbours {
    public static void main(String[] args) {
        int[] arr = {1,5,4,6,3};
        List<Integer>list= new ArrayList<>();
        for (int i=1;i<arr.length-1;i++){
            if (arr[i] > arr[i - 1] && arr[i] > arr[i+1]) {
                list.add(arr[i]);
            }
        }

        Collections.sort(list);
        System.out.println(list.getLast());
    }
}
