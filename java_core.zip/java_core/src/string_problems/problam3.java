package string_problems;

public class problam3 {
    public static void main(String[] args) {
       String s = "A man, a plan, a canal: Panama";
       String s1 ="";
       String s2 ="";
       s=s.toLowerCase();

       for (int i = 0;i<s.length();i++){
           if (Character.isLetter(s.charAt(i))){
               s1+=s.charAt(i);
           }
       }
       for (int i=s1.length()-1;i>=0;i--){
           s2+=s1.charAt(i);
       }
       if (s1.equals(s2)){
           System.out.println("it is palindrome string");
       }
       else {
           System.out.println("it is not palindrome string");
       }
        System.out.println(s1+" "+s2);
    }
}
