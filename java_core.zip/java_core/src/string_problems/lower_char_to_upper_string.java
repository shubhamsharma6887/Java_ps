package string_problems;

public class lower_char_to_upper_string {
    public static void main(String[] args) {
        String s = "Shubham Sharma";
        String result ="";
        for (int i=0;i<s.length();i++){
            char c = '0';
            if ((int)(s.charAt(i))>=97 && (int)(s.charAt(i))<=122){
                c=(char)((s.charAt(i))-32);

                result+=c;
            } else {
                result+=s.charAt(i);
            }
        }
        System.out.println(result);
    }
}
