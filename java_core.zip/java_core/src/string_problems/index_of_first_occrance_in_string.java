package string_problems;

// Find the Index of the First Occurrence in a String

public class index_of_first_occrance_in_string {
    public static void main(String[] args) {
        String s = "sasadbutsad", s1 = "sad";
        for (int i=0;i<s.length();i++){
            if(s.charAt(i)==s1.charAt(0)){
                for (int j=1;j<s1.length();j++){
                    if(s.charAt(i+j)==s1.charAt(j)){
                        j++;
                        if (s.charAt(i+j)==s1.charAt(j)){
                            System.out.println(i);
                        }
                    }
                }
            }
        }
    }
}
