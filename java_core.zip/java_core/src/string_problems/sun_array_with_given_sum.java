package string_problems;

import java.util.ArrayList;
import java.util.List;

public class sun_array_with_given_sum {
    public static void main(String[] args) {
        int[] arr = {1,3,4,7};
        int count=0;
        List<Integer> list = new ArrayList<>();
        for (int i=0;i<arr.length;i++){
            count+=arr[i];
            list.add(arr[i]);
            for (int j=0;j<arr.length;j++){
                if (i==j){
                    continue;
                }
                count+=arr[j];
                list.add(arr[j]);
                if (count==8){
                    System.out.println(list);
                    list.clear();
                    count=0;
                }
            }
            list.clear();
            count=0;
        }
    }
}
