package string_problems;

public class problam2 {
    public static void main(String[] args) {

    }
}

