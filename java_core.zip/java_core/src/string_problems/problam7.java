package string_problems;

public class problam7 {
    public static void main(String[] args) {
        String s = "shubh@m sharma";
        String rev="";
        int pos = 0;
        char symbol = '0';
        for (int i=s.length()-1;i>=0;i--){
            if(Character.isLetter(s.charAt(i))){
                rev+=s.charAt(i);
            }
            else {
                pos=i;
                symbol=s.charAt(i);
            }
        }
        for (int j=0;j<rev.length();j++){
            if (pos==j){
                System.out.print(symbol);
            }
            else{
                System.out.print(rev.charAt(j));
            }
        }
    }
}
