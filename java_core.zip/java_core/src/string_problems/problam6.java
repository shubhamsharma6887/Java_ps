//reverse string with placing a character at its original position
package string_problems;

public class problam6 {
    public static void main(String[] args) {
        String s = "s2hubham sharma";
        int pos = s.indexOf('2');
        int pos2 = s.length() - pos -1;
        for (int i=s.length()-1;i>=0;i--){
            if (pos==i){
                continue;
            }
            if (pos2==i){
                System.out.print("2");
            }
            System.out.print(s.charAt(i));
        }
    }
}
