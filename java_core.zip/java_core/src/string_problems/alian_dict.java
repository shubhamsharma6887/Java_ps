package string_problems;

public class alian_dict {
    public static void main(String[] args) {
        String[] words = {"hello","leetcode"};
        String order = "hlabcdefgijkmnopqrstuvwxyz";
        for (int i=0;i<order.length();i++){
            String word1= words[i];
            String word2= words[i+1];

            int index = 0;

        }
    }
}
