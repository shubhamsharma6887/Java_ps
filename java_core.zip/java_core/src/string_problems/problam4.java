package string_problems;



public class problam4 {
    public static void main(String[] args) {
        String s = "A man, a plan, a canal: Panama";
        int count = 0;
        while (true){
            try {
                char cc = s.charAt(count);
                count++;
            } catch (IndexOutOfBoundsException r){
                break;
            }
        }
        System.out.println(count);
        System.out.println(s.length());
    }
}

