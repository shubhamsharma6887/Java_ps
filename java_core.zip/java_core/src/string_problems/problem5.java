package string_problems;

public class problem5 {
    public static void main(String[] args) {
        String s = "shubhams";
        String lsub ="";
        for (int i = 0; i<s.length();i++){
            String sub="";
            for (int j=1;j<s.length();j++){
                if (s.charAt(i)!=s.charAt(j)){
                    sub+=s.charAt(i);
                    if(s.charAt(i)==s.charAt(j)){
                        break;
                    }

                }
                lsub=sub;
            }
            System.out.println(lsub);
        }
    }
}
