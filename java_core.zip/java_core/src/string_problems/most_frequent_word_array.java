package string_problems;

//Given an array of strings, find the most frequent word in a given array, I mean, the string that appears the most in the array. In the case of a tie, ​the string that is the smallest (lexicographically) ​is printed.

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class most_frequent_word_array {
    public static void main(String[] args) {
        String[] arr ={"apple","ball","cat","dog","apple","ball","apple"};
        LinkedHashMap<String,Integer> count = new LinkedHashMap<>();
        for (int i=0;i<arr.length;i++){
            if (count.containsKey(arr[i])){
                count.put(arr[i],count.get(arr[i])+1);
            } else {
                count.put(arr[i],1);
            }
        }
        for (Map.Entry<String,Integer> ok: count.entrySet()){
            for (int j=0;j>count.size();j++){

            }
        }
    }
}
