package rough;


public class Main {
    public static void main(String[] args) {
        String str = "tushar";
        String substr = "sh";
        String replace = "pa",ans="";
        boolean flag=false;
        for (int i = 0; i < str.length(); i++) {
            if(str.charAt(i)==substr.charAt(0)){
                for(int j=1 ;j<substr.length();j++){
                    if(str.charAt(i+j)==substr.charAt(j)){
                       flag=true;
                    }
                    else{
                        flag=false;
                        ans+=str.charAt(i);
                        break;
                    }

                }
                if(flag){
                    ans+=replace;
                    i+=substr.length()-1;
                }
            }
            else{
                ans+=str.charAt(i);
            }
        }
        System.out.println(ans);
    }
}