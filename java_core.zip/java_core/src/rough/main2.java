package rough;

public class main2 {
    public static void main(String[] args) {
        String[] arr = {"geeksforgeeks", "geeks", "geek", "geezer"};
        String prefix ="";
        for (int i=0;i<arr[0].length();i++){
            char cc = arr[0].charAt(i);
            boolean flag = true;
            for (int j=1;j<arr.length;j++){
                if (i>arr[i].length() || arr[j].charAt(i) != cc){
                    flag = false;
                    break;
                }

            }
            if (flag){
                prefix+=cc;
            } else {
                break;
            }
        }
        System.out.println(prefix);
    }
}
