package rough;

import java.util.HashMap;
import java.util.Map;

public class shubham {
    public static void main(String[] args) {
        String S = "shubham sharma";
        Map<Character, Integer> cc = new HashMap<>();

        // Removing spaces and converting to lowercase for case-insensitive counting
        S = S.replace(" ", "").toLowerCase();

        // Counting occurrences of each character
        for (char c : S.toCharArray()) {
            cc.put(c, cc.getOrDefault(c, 0) + 1);
        }

        // Displaying the counts
        System.out.println("Repeating characters and their counts:");
        for (Map.Entry<Character, Integer> entry : cc.entrySet()) {
            if (entry.getValue() > 1) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
        }
    }
}
