package rough;

public class rough {
    public static void main(String[] args) {
        String s = "this boy is smart";
        String s1 = "smart";
        String s2 = "";
        boolean flag = true;
        for (int i = 0; i < s.length(); i++) {
            if (s1.charAt(0) == s.charAt(i)) {
                for (int j = 1; j < s1.length(); j++) {
                    if (s1.charAt(j) == s.charAt(i+j)) {
                        flag=true;
                        continue;
                    } else {
                        flag=false;
                        s2+=s.charAt(i);
                        break;
                    }
                }
                if(flag){
                    i+=s1.length()-1;

                }
            } else {
                s2+=s.charAt(i);
            }
        }
        System.out.println(s2);
    }
}
