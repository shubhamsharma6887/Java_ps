package rough;

public class example2 {
    public static void main(String[] args) {
        String a = "aashish";
        StringBuilder uniqueChars = new StringBuilder();

        for (int i = 0; i < a.length(); i++) {
            char currentChar = a.charAt(i);
            boolean isRepeated = false;

            for (int j = 0; j < i; j++) {
                if (a.charAt(j) == currentChar) {
                    isRepeated = true;
                    break;
                }
            }

            if (!isRepeated) {
                uniqueChars.append(currentChar);
            }
        }

        System.out.println(uniqueChars.toString());
    }
}
