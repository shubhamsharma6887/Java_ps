package rough;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class sorted {
    public static void main(String[] args) {
        List<Integer> list = List.of(5,4,3,23,64,63);
        List<Integer> sl = list.stream().sorted().collect(Collectors.toList());
        System.out.println(sl);

    }
}
