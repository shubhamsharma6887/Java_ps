package top_100_coding_question;

public class armstrong_number {
    public static void main(String[] args) {
        int num = 153, sum=0,n=num;
        num=num/10;

    }
}
