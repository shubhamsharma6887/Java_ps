package top_100_coding_question;

public class positive_negative_number {
    public static void main(String[] args) {
        int num = 1;
        if (num>0){
            System.out.println(num+" is positive number");
        } else if (num<0) {
            System.out.println(num+" is negative number");
        } else {
            System.out.println("number is zero");
        }
    }
}
