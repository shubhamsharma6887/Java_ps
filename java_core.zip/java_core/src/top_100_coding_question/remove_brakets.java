package top_100_coding_question;

public class remove_brakets {
    public static void main(String[] args) {
        String s = "(a+b)=c";
        String c = "[a+b]=c";
        String i = "{a+b}=c";
        String s1 = s.replaceAll("[()]", "");
        String c1 = c.replaceAll("[\\[\\]]","");
        String i1 = i.replaceAll("[{}]","");
        System.out.println(s1);
        System.out.println(c1);
        System.out.println(i1);
    }
}
