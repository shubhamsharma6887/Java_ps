package top_100_coding_question;

public class extract_palindrome_String {
    public static void main(String[] args) {
        String ww ="153";
        int pnum= Integer.parseInt(ww), s=0, sum=0;
        for (int i = 0;i<=ww.length();i++){
            int n = pnum/10;
            s=pnum%10;
            s= (int) Math.pow(s,3);
            sum+=s;
            pnum=n;
        }
        System.out.println(sum);
    }
}
