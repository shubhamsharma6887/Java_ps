package top_100_coding_question;

public class vowel_or_consonet {
    public static void main(String[] args) {
       String s = "shubham 777 sharma";
       int num=1;
       for (int i=0;i<s.length();i++){
           if (Character.isDigit(s.charAt(i))){
               String s1 = Character.toString(s.charAt(i));
               int l = Integer.parseInt(s1);
               num*=l;
           }
       }
        System.out.println(num);
    }
}
