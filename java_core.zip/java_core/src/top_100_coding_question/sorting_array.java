package top_100_coding_question;

import java.lang.reflect.Array;
import java.util.Arrays;

public class sorting_array {
    public static void main(String[] args) {
        int[] arr = { 8, 7, 5, 9, 12, 10};
        int half = arr.length/2;
        Arrays.sort(arr);
        for (int i=0;i<half;i++){
            System.out.print(arr[i]+" ");
        }
        for (int i=arr.length-1;i>=half;i--){
            System.out.print(arr[i]+" ");
        }
    }
}
