package top_100_coding_question;

import java.util.HashMap;
import java.util.Map;

public class count_occrance_of_char {
    public static void main(String[] args) {
        String name = "Shubham Sharma";
        HashMap<Character,Integer> cc = new HashMap<>();
        cc.put('r',3);
        name = name.replace(" ","").toLowerCase();
        for (int i=0;i<name.length();i++){
            char arr = name.charAt(i);
            if(Character.isLetter(arr)){
                cc.put(arr,cc.getOrDefault(arr,0)+1);
            }
        }
        for (Map.Entry<Character, Integer> entry : cc.entrySet()) {
            if (entry.getValue() > 1) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
        }
    }
}
