package top_100_coding_question;

public class lenthofstring {
    public static void main(String[] args) {
        String s = "shubham sharma";
        char[] arr = s.toCharArray();
        int lenth = 0;
        for (char ok:arr){
            lenth++;
        }
        System.out.println(lenth);
    }
}
