package top_100_coding_question;

public class factor_of_num {
}
