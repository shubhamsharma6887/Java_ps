package top_100_coding_question;

import java.util.HashSet;

public class count_distinct_element_arr {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 1, 2, 3, 6, 7, 8, 9, 10, 10};
        HashSet<Integer> uniquecount = new HashSet<>();
        for (int i=0;i<arr.length;i++){
            uniquecount.add(arr[i]);
        }
        System.out.println(uniquecount.size());
    }
}