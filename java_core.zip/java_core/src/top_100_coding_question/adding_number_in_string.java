package top_100_coding_question;

public class adding_number_in_string {
    public static void main(String[] args) {

    }
}
