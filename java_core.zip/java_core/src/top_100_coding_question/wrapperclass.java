package top_100_coding_question;

public class wrapperclass {
    public static void main(String[] args) {
        Integer i = 45;
        System.out.println(i.toString());
        System.out.println(System.currentTimeMillis()/1000/3600/24/365);
    }
}
