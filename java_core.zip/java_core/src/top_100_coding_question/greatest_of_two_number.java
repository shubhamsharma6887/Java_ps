package top_100_coding_question;

public class greatest_of_two_number {
    public static void main(String[] args) {
        int num1 = 11, num2= 10;
        if (num1<num2){
            System.out.println(num2+" is greatest");
        } else if (num1==num2) {
            System.out.println("both number are equal");
        } else {
            System.out.println(num1+" is greatest");
        }
    }
}
