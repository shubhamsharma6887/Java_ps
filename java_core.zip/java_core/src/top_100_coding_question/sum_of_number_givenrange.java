package top_100_coding_question;

public class sum_of_number_givenrange {
    public static void main(String[] args) {
        int a= 5,b=10,sum=0;
        for (int i = a;i<=b;i++){
            sum=sum+i;
        }
        System.out.println(sum);
    }
}
