package top_100_coding_question;

public class subsetofstring {
    public static void main(String[] args) {
        String arr = "shubham";
        String sum="",ok="";
        for (int i = 0;i<arr.length();i++) {

        }

    }
}
