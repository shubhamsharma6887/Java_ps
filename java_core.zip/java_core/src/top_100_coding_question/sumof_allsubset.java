package top_100_coding_question;

public class sumof_allsubset {
    public static void main(String[] args) {
        int [] arr = {5,4,3};
        int sum=0;
        for (int i = 0;i<arr.length;i++){
            sum+=arr[i];
            System.out.println(arr[i]);
            for (int j = i+1;j<arr.length;j++){
             int ok = arr[i]+arr[j];
                System.out.println(arr[i]+"+"+arr[j]+"= "+ok);
            }
        }
        System.out.println(sum);
    }
}
