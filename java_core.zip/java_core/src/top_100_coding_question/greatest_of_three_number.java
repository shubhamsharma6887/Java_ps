package top_100_coding_question;

public class greatest_of_three_number {
    public static void main(String[] args) {
        int a = 5, b = 2, c= 1;
        if (a==b && b==c){
            System.out.println("all number are same");
        } else if (b>=a && b>=c){
            System.out.println(b+" is the greatest number ");
        } else if (c>=a && c>=b) {
            System.out.println(c+" is the greatest number ");
        } else if (a>=b && a>=c){
            System.out.println(a+" is the greatest number");
        }
    }
}
