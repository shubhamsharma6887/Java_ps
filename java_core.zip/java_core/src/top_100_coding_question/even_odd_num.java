package top_100_coding_question;

public class even_odd_num {
    public static void main(String[] args) {
        int num = 9;
        if (num%2==0){
            System.out.println(num+" is a even number");
        } else{
            System.out.println(num+" is a odd number");
        }
    }
}
