package top_100_coding_question;

public class String_reverse_tushar {
    public static void main(String[] args) {
        String s = "s!hubham";
        String rev = "";
        int pos = 0;
        char symbol = ' ';
        for (int i=s.length()-1;i>=0;i--){

            //char c = s.charAt(i);
            // if(((int)c >=65 && (int)c <=91) || ((int)c >=97 && (int)c<=123)){
            //       w+=s.charAt(i);
            // }

            if(Character.isLetter(s.charAt(i))){
                rev+=s.charAt(i);
            } else {
                pos=i;
                symbol=s.charAt(i);
            }
        }
        for (int j=0;j<rev.length();j++){
            if (pos==j){
                System.out.print(symbol);
            }
            System.out.print(rev.charAt(j));
        }

    }
}
