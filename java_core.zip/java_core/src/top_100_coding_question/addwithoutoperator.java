package top_100_coding_question;

public class addwithoutoperator {
    public static int add(int a, int b){
        while (b!=0){
            int c = a & b;
            a = a^b;
            b = c << 1;
        }
        return a;
    }

    public static void main(String[] args) {
        int num1 = 5;
        int num2 = 5;
        int sum = add(num1,num2);
        System.out.println(sum);
    }
}
