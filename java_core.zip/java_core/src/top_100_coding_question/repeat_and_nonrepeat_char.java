package top_100_coding_question;

import java.util.ArrayList;
import java.util.HashSet;

public class repeat_and_nonrepeat_char {
    public static void main(String[] args) {
        String s = "shubham sharma";
        ArrayList<Character> repeat = new ArrayList<>();
        HashSet<Character> c = new HashSet<>();
        for (int i =0;i<s.length();i++){
            if (c.add(s.charAt(i))){
                continue;
            }
            else {
                c.remove(s.charAt(i));
                repeat.add(s.charAt(i));
            }
        }
        System.out.println("repeating character are "+repeat);
        System.out.println("unique character are "+c);
    }
}