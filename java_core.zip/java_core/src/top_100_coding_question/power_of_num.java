package top_100_coding_question;

public class power_of_num {
}
