package practice_set;
interface BasicAnimal{
    void eat();
    void sleep();
}
class Monkey{
    void jump(){
        System.out.println("monkey is jumping");
    }
    void bite(){
        System.out.println("monkey is bitting");
    }
}
class Human extends Monkey implements BasicAnimal{
    public void eat(){
        System.out.println("eating");
    }
    public void sleep(){
        System.out.println("sleeping");
    }
    public void speak(){
        System.out.println("speaking");
    }
}
public class interface_practice {
    public static void main(String[] args) {
        Human h = new Human();
        h.eat();
        h.sleep();
        h.jump();
        h.bite();
        Monkey m = new Human();
        BasicAnimal ba = new Human();

    }
}
