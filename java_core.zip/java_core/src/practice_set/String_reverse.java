package practice_set;
public class String_reverse {
    public static void main(String[] args) {
        String s = "s1hubham sharma";
        int pos = s.indexOf('1');
        int pos2 = s.length() - pos - 1;
        for (int i = s.length() - 1; i >= 0; i--) {

            if (i == pos2) {
                System.out.print('1');
            }
            if (s.charAt(i) == '1') {
                continue;
            }
            System.out.print(s.charAt(i));

        }
    }
}
