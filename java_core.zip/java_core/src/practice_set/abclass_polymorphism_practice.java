package practice_set;
abstract class Telephone{
    abstract void ring();
    abstract void lift();
    abstract void disconnect();
}
class SmartTelephone extends Telephone{
    public void ring(){
        System.out.println("phone is ringing");
    }
    public void lift(){
        System.out.println("lifting the phone");
    }
    public void disconnect(){
        System.out.println("disconnecting the phone");
    }
    public void camera(){
        System.out.println("opening the camera");
    }
    public void bluetooth(){
        System.out.println("turning on the bluetooth");
    }
}
public class abclass_polymorphism_practice {
    public static void main(String[] args) {
        Telephone t = new SmartTelephone();
        t.ring();
        t.lift();
        t.disconnect();

        SmartTelephone st = new SmartTelephone();
        st.bluetooth();
        st.camera();
    }
}
