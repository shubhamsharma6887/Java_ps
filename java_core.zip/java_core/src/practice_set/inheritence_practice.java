package practice_set;

import java.awt.geom.Area;

class Circle{
    double radius;
    double area;
    public Circle(int radius){
        this.radius=radius;
    }
    public double areaofcircle(){
        area = Math.PI*this.radius*this.radius;
        return area;
    }
}
class Cylinders extends Circle{
    double height;
    double volume;
    public Cylinders(int radius, int height){
        super(radius);
        this.height=height;
    }
    public double volumeofcylinder(){
        volume = Math.PI*this.radius*this.radius*height;
        return volume;
    }
}
public class inheritence_practice {
    public static void main(String[] args) {
        Circle c1 = new Circle(4);
        System.out.println(c1.areaofcircle());
        Cylinders v1 = new Cylinders(4,4);
        System.out.println(v1.volumeofcylinder());

    }
}
