package practice_set;
class Cylinder{
    double pie = 3.14;
    double radius;
    double height;
    double volume;
    public Cylinder(double myradius, double myheight){
        radius=myradius;
        height=myheight;
    }
    public Cylinder(){
        radius= 00;
        height= 00;
    }
    public void setRadius(double radius){
        this.radius=radius;
    }
    public void setHeight(double height){
        this.height=height;
    }
    public double getRadius(){
        return radius;
    }
    public double getHeight(){
        return height;
    }
    public double getVolume(){
        volume=pie*radius*radius*height;
        return volume;
    }
}
public class constructor_practice1 {
    public static void main(String[] args) {
        Cylinder c1 = new Cylinder(10,10);
        System.out.println(c1.getVolume());
    }
}
