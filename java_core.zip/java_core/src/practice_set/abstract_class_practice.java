package practice_set;
abstract class Pen{
    abstract void write();
    abstract void refil();
}
class Cello extends Pen{
    public void write(){
        System.out.println("writing with the pen");
    }
    public void refil(){
        System.out.println("refiling with the pen");
    }
}
public class abstract_class_practice {
    public static void main(String[] args) {
        Cello p1 = new Cello();
        p1.write();
        p1.refil();
    }
}
