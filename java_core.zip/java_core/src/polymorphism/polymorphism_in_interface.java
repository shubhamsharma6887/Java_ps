package polymorphism;


interface Camera2{
    void takesnap();
    void recordvideo();
    private void status (){
        System.out.println("camera is running");
    }
    // default methods
    default void record4kvideo(){
        //status();  // can use private method in interfaces by this method
        System.out.println("Recording in 4k");
    };
}
interface Wifi2{
    String[] getnetworks();
    void conecttonetwork(String network);
}
class MyCellphone2{
   public  void callnumber(long num){
        System.out.println("Calling the number: "+num);
    }
     public void pickcall(){
        System.out.println("Reciving call from :");
    }
}
class Smartphone2 extends MyCellphone2 implements Camera2,Wifi2 {
    public void takesnap(){
        System.out.println("Taking snap");
    }
    public void recordvideo(){
        System.out.println("recording video");
    }
    public String[] getnetworks(){
        System.out.println("getting list of networks");
        String[] networklist = {"jio","Airtel","idea"};
        return networklist;
    }
    public void conecttonetwork(String network){
        System.out.println("conecting to "+network);
    }
    //overriding default method in Camera interface
    @Override
    public void record4kvideo(){
        System.out.println("Recording video in 4k and in 60 fps");
    }
}
public class polymorphism_in_interface {
    public static void main(String[] args) {
        Camera2 cam = new Smartphone2(); // this is a smartphone but use it as a camera

        // cam.getnetworks();  not allowed
        Wifi2 w = new Smartphone2();
        w.conecttonetwork("Jio");
        Smartphone2 s = new Smartphone2();
        s.callnumber(881743115);
        MyCellphone2 mc = new Smartphone2();
        mc.pickcall();
    }
}

// implementing an interface force method implementation