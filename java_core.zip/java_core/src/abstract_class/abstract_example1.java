package abstract_class;

abstract class Sound{
    abstract public void speak();
}
class Dog extends Sound{
    public void speak(){
        System.out.println("bhaw bhaw");
    }
}
class Cat extends  Sound{
    public void speak(){
        System.out.println("myou myou");
    }
}
class Human extends Sound{
    public void speak(){
        System.out.println("hello");
    }
}
public class abstract_example1 {
    public static void main(String[] args) {
        Dog jhony = new Dog();
        jhony.speak();
        Cat ok = new Cat();
        ok.speak();
        Human harry = new Human();
        harry.speak();
    }
}
