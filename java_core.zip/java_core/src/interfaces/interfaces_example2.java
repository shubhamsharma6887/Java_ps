package interfaces;

interface Bicycle{
    int a = 45;
    void applybreak(int decrement);
    void speedup(int increment);
}
interface GearBicycle{
    void geardown(int decrement);
    void gearup(int increment);
}
class AvonCycle implements Bicycle, GearBicycle{
    void blowhorn(){
        System.out.println(" pee pee ");
    }
    public void applybreak(int decrement){
        System.out.println("Applying Break");
    }
    public void speedup(int increment){
        System.out.println("Applying speedup");
    }
    public void gearup(int increament){
        System.out.println("Applying gear up");
    }
    public void geardown(int decrement){
        System.out.println("Applying gear down");
    }
}
public class interfaces_example2 {
    public static void main(String[] args) {
        AvonCycle c = new AvonCycle();
        c.applybreak(1);
        // you can create properties in interfaces
        // you can not modify the properties in interfaces as they are final
        System.out.println(c.a);
        c.gearup(1);
        c.geardown(1);
    }
}
