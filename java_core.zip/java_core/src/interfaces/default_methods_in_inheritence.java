package interfaces;

interface Camera{
    void takesnap();
    void recordvideo();
    private void status (){
        System.out.println("camera is running");
    }
    // default methods
    default void record4kvideo(){
        //status();  // can use private method in interfaces by this method
        System.out.println("Recording in 4k");
    };
}
interface Wifi{
    String[] getnetworks();
    void conecttonetwork(String network);
}
class MyCellphone{
    void callnumber(int num){
        System.out.println("Calling the number: "+num);
    }
    void pickcall(){
        System.out.println("Reciving call from :");
    }
}
class Smartphone extends MyCellphone implements Camera,Wifi {
    public void takesnap(){
        System.out.println("Taking snap");
    }
    public void recordvideo(){
        System.out.println("recording video");
    }
    public String[] getnetworks(){
        System.out.println("getting list of networks");
        String[] networklist = {"jio","Airtel","idea"};
        return networklist;
    }
    public void conecttonetwork(String network){
        System.out.println("conecting to "+network);
    }
    //overriding default method in Camera interface
    @Override
    public void record4kvideo(){
        System.out.println("Recording video in 4k and in 60 fps");
    }
}
public class default_methods_in_inheritence {
    public static void main(String[] args) {
        Smartphone sp = new Smartphone();
        String[] ar = sp.getnetworks();
        for (String item:ar){
            System.out.println(item);
        }
        sp.record4kvideo();
    }
}
