package interfaces;

import java.awt.image.PixelGrabber;

interface Animal{
    public void animalsound();
    public void sleep();
}
interface Human{
    public void humansound();
    public void sleep();
}

class Pig implements Animal,Human{
    public void animalsound(){
        System.out.println("the pig says: wee wee");
    }
    public void sleep(){
        System.out.println("Zzz");
    }
    public void humansound(){
        System.out.println("hello bete");
    }
}
public class interfaces_example {
    public static void main(String[] args) {
        Pig p = new Pig();
        p.animalsound();
        p.sleep();
        p.humansound();
    }
}
