package integer;

public class example1 {
    public static void main(String[] args) {
        int num=343;
        int rev=0,i=1;
        int c = num;
        while (num>0){
            rev+=(num%10)*i;
            i*=10;
            num/=10;
        }
        if (rev==c){
            System.out.println("palindrome");
        } else {
            System.out.println(rev);
        }
    }
}
