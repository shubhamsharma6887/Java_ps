package collection_framwork.list;

import java.util.LinkedList;

public class linked_list {
    public static void main(String[] args) {
        LinkedList<Integer> l1 = new LinkedList<>();
        l1.add(3);
        l1.add(5);
        l1.add(6);
        l1.addFirst(1);
        l1.addLast(8);
        l1.offerFirst(7);
        System.out.println(l1);
    }
}
