package collection_framwork.list;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Array_list {
    public static void main(String[] args) {
        ArrayList<Integer> l1 = new ArrayList<>();
        l1.add(8);
        l1.add(2);
        l1.add(0);
        l1.add(4);
        l1.add(6);
        Collections.sort(l1);
        System.out.println(l1);
        System.out.println(l1.get(0));


    }
}
