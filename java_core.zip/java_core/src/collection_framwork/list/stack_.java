package collection_framwork.list;

import java.util.Collections;
import java.util.Stack;

public class stack_ {
    public static void main(String[] args) {
        Stack<Integer> list = new Stack<>();
        list.push(5);
        list.push(4);
        list.push(2);
        list.push(9);
        list.add(1,12);
        Collections.sort(list);
        list.pop();
        System.out.println(list);
        System.out.println(list.peek());
    }
}
