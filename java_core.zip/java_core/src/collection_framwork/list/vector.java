package collection_framwork.list;

import java.util.Collections;
import java.util.Vector;

public class vector {
    public static void main(String[] args) {
        Vector<String> cars = new Vector<>();
        cars.add("tata");
        cars.add("mg hector");
        cars.add("bmw");
        Collections.sort(cars);
        System.out.println(cars);

    }
}
