package collection_framwork.set;

import java.util.HashSet;
import java.util.Iterator;

public class hashset {
    public static void main(String[] args) {
        HashSet<String>  cars = new HashSet<>( );
        cars.add("Volvo");
        cars.add("BMW");
        cars.add("Ford");
        cars.add("BMW");
        cars.add("Mazda");
        Iterator<String> it = cars.iterator();
        System.out.println(it.hasNext());
        while(it.hasNext()) {
            System.out.println(it.next());
        }
    }
}
