package collection_framwork.set;

import java.util.LinkedHashSet;

public class linkedhashset {
    public static void main(String[] args) {
        LinkedHashSet<Integer> list = new LinkedHashSet<>();
        list.add(5);
        list.add(2);
        list.add(8);
        list.add(8);
        list.add(4);
        System.out.println(list);
    }
}
