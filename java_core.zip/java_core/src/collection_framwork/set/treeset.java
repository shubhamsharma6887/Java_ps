package collection_framwork.set;

import java.util.TreeSet;

public class treeset {
    public static void main(String[] args) {
        TreeSet<Integer> ts = new TreeSet<>();
        ts.add(5);
        ts.add(2);
        ts.add(8);
        ts.add(8);
        ts.add(4);
        System.out.println(ts);
    }
}
