package collection_framwork.set;

import java.util.HashSet;

public class sets {
    public static void main(String[] args) {
        String s = "shubham sharma";
        HashSet<Character> hs = new HashSet<>();
        HashSet<Character> hs2 = new HashSet<>();
        for (int i=0;i<s.length();i++){
            if (hs.add(s.charAt(i))){
                hs2.add(s.charAt(i));
            } else {
                if (hs2.contains(s.charAt(i))){
                    hs2.remove(s.charAt(i));
                }
            }
        }
        System.out.print(hs2.toString());
    }
}
