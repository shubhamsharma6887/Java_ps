package collection_framwork.map;

import java.util.HashMap;

public class hashmap {
    public static void main(String[] args) {
        HashMap<Integer,String> city = new HashMap<>();
        city.put(457226,"Jaora");
        city.put(452001,"Indore");
        city.put(452002,"Indore");
        city.put(452002,"bhopal");
        for (Integer i:city.keySet()){
            System.out.println(city.get(i));
        }
    }
}
