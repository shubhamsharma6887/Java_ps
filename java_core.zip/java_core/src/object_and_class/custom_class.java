package object_and_class;

class Employee{
    int salary;
    String name;
    public int getSalary(){
        return salary;
    }
    public String getName(){
        return name;
    }

    public void setSalary(int salary){
        this.salary = salary;
    }
    public void setName(String name){
        this.name = name;
    }
    public void printdetails(){
        System.out.println("my name is "+ name);
        System.out.println("my salary is "+ salary);
    }
}
public class custom_class {
    public static void main(String[] args) {
        Employee harry = new Employee();
        harry.setName("harry sharma");
        harry.setSalary(25000);
        harry.printdetails();


    }
}
