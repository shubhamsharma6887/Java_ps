package object_and_class;

class Myemployee{
    private int id;
    private String name;
    public void setName(String name){
        this.name=name;
    }
    public void setId(int id){
        this.id=id;
    }
    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }
}
public class acsess_modifiers {
    public static void main(String[] args) {
        Myemployee harry = new Myemployee();
        harry.setId(101);
        harry.setName("kanak sharma");
        System.out.println(harry.getId()+" "+harry.getName());
    }
}
