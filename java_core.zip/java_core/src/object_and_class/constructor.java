package object_and_class;
class MyMainemployee{
    private int id;
    private String name;
    public MyMainemployee(int myid,String myname){
        id = myid;
        name = myname;
    }
    public MyMainemployee(){
        id = 00;
        name ="your name";
    }
    public void setName(String name){
        this.name=name;
    }
    public void setId(int id){
        this.id=id;
    }
    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }

}
public class constructor {
    public static void main(String[] args) {
        MyMainemployee harry = new MyMainemployee();
        System.out.println(harry.getId()+" "+harry.getName());
    }
}
